# LumaPOS — Consolidated Master Design Prompt (v2)

> Single authoritative brief for designing **LumaPOS**. Hand this whole file to Claude Design.
> **How to use:** This is long. Do not try to execute every step in one shot — work step by step, surface by surface. Foundations (Parts 0–3) define the system; later parts apply it.
> **Bilingual convention** used throughout for UI labels: `English / Tiếng Việt` or `English (Vietnamese subtext)`. English = primary weight, full charcoal; Vietnamese = lighter weight, ~60% opacity.

---

## PART 0 — Role & Global Directives

You are a Principal Product Manager, Principal UX Designer, Flutter Architect, Enterprise Solution Architect, and AI Product Designer.

Design **LumaPOS**: an intelligent, AI-integrated Point of Sale (POS) management platform for individual retailers, small shops, and medium-sized enterprises in Vietnam.

**Targets:** Web Admin · Android · iPhone · Tablet POS. Scalable, extensible, optimized for Flutter.

**Core principles:** Simplicity · Modernity · Low learning curve · High-speed operations · Offline-first · Seamless cloud sync on reconnect · **Native bilingual (English & Vietnamese)** core with an intuitive UI language switcher.

**Localization constraint (applies to every component):** Cards, tables, buttons, and flex containers must expand dynamically to absorb Vietnamese strings (30–40% longer than English) without clipping text or breaking layout.

---

## PART 1 — Foundations (Vision → Screens)

Deliver: (1) Product Vision, (2) Product Goals, (3) User Personas, (4) Product Map, (5) Information Architecture, (6) User Flows, (7) full screen inventory.

* **Product Goals must be measurable.** Define a north-star metric and supporting KPIs: activation (first sale completed), time-to-checkout, daily active stores, retention, crash-free session rate, sync-success rate.
* **Vietnamese-market context:** briefly benchmark against KiotViet, Sapo, Haravan, POS365 to sharpen differentiation — without copying any of them.

*Do not generate UI layouts in this part.*

---

## PART 2 — Modular, Multi-Industry Architecture

**Shared core modules:** POS · Products · Inventory · Invoices/Receipts · Customers (CRM) · Reports & Analytics · AI Assistant · Settings.

**Supported industries:** Grocery · Mini-mart/Convenience · Fashion & Apparel · Cosmetics & Beauty · Bookstores · Electronics & Appliances · Restaurants · Cafes · Service businesses · Pet shops · Mobile/Gadget stores · Construction materials.

On store creation the user picks an industry; LumaPOS then automatically toggles relevant modules, adapts the UI, adjusts data fields/schemas, and calibrates workflows. The industry config also drives **compliance settings** (e-invoice applicability, tax rates — Part 13) and **vertical flows** (F&B → Part 18; product-grid default — Part 6.C).

Design an **open architecture** to onboard new industries later. Include **schema versioning/migration** so toggling industries or upgrading later never corrupts existing data.

---

## PART 3 — Design System

Material Design 3 compliant · 8pt grid · 16px default radius · responsive (Web/Tablet/Mobile) · native Light & Dark mode · fully optimized for native Flutter widgets.

**Tokens & components:** Color palette & tokens · Typography scale · Buttons (Elevated/Filled/Tonal/Outlined/Text) · Text fields & forms · Search bars · Cards/containers · Data tables · Charts · Dialogs/modals · Bottom sheets · Navigation (Navbar/Rail/Drawer) · Toasts/snackbars · Empty/Loading/Error states · Iconography · Elevation/shadow tokens · Micro-interactions/animations.

**Every component must define all interaction states** (default/hover/pressed/focused/disabled/loading/error) and every module must define empty/first-time states.

**Craft upgrades (override M3 defaults — see Part 3.5 for rationale):**
* **Typography:** Primary face = **Be Vietnam Pro** (built for Vietnamese, full diacritics, has character) — not Roboto. Numeric/data face = a tabular/monospace family (Geist Mono / JetBrains Mono); always enable tabular figures so columns align. Body text = charcoal `#1F2024` (never pure black); secondary `#6B6F76`; line-height ~1.5–1.6.
* **Color:** Keep the M3 token system but bias the neutral ramp **warm** (canvas `#FAFAF8`, surface `#FFFFFF`/`#F7F6F3`). One restrained brand accent. Status uses **muted semantic pastels** only — pale green (in-stock/paid), pale yellow (low-stock/pending), pale red (out-of-stock/failed), pale blue (info); text-on-pastel must meet AA. Hairline dividers `#EAEAEA`. Full warm-neutral dark mode (not pure black).
* **Shape & elevation:** 16px card radius; pills (9999px) for tags/badges only; inputs 8–12px. Elevation = ultra-diffuse low-opacity shadow (<0.06) + 1px hairline — never harsh `shadow-md/lg`.
* **Iconography:** one consistent set, standardized stroke weight (Phosphor-style or a tuned M3 set); slightly heavier stroke for POS-distance legibility.
* **Brand direction:** define logo usage, brand voice, and accent rationale — not just raw tokens.

---

## PART 3.5 — Taste Layer (Anti-Slop Craft Directive)

A cross-cutting directive over all UI parts. Adapted from anti-slop product-UI principles; the audience picks the aesthetic, not our taste — a cashier mid-rush needs speed over spectacle.

**Per-surface dials** — `DESIGN_VARIANCE` (1 symmetric→10 chaotic) · `MOTION_INTENSITY` (1 static→10 cinematic) · `VISUAL_DENSITY` (1 airy→10 cockpit):

| Surface | VARIANCE | MOTION | DENSITY |
|---|---|---|---|
| POS Terminal | 3 | 2 | 7 |
| Inventory / Data tables | 3 | 1 | 8 |
| Executive Dashboard | 6 | 5 | 4 |
| AI Assistant | 4 | 3 | 4 |
| Onboarding / Empty / Marketing | 7 | 6 | 3 |

**Banned defaults (do the alternative):** raw Roboto/Inter as the brand face · AI-purple gradients / dark-mesh hero / glassmorphism-on-everything (glass only on sticky cart bar & modal scrims) · three identical equal-width cards (use asymmetric bento on dashboards; uniform grids only where data parity demands) · heavy drop shadows · infinite-loop animations on operational screens · placeholder content ("John Doe", "Lorem Ipsum" → realistic VN retail data) · copy clichés ("Elevate", "Seamless", "Next-Gen") · emojis in UI text · `rounded-full` on large containers.

**Motion, gated by dials:** custom curves only (standard `Cubic(0.32,0.72,0.0,1.0)`; gentle entry `Cubic(0.16,1,0.3,1)`) — no linear/ease-in-out. Operational surfaces: only `scale(0.98)` press + 120–160ms fades, no scroll reveals, nothing that delays a tap result. Dashboard/Onboarding: scroll-entry fade-up, staggered reveals (`index*80ms`), at most one slow ambient gradient. Animate only `transform`/`opacity`. Honor reduced-motion globally.

**"Double-bezel" nested cards** (outer shell + inner core, concentric radii) only on Dashboard hero KPI tiles and the AI Smart-Restock panel — never on POS keypad, cart rows, or table cells.

**Web→Flutter translation:** CSS vars → `ThemeData` + central `AppTokens`; `cubic-bezier` → `Cubic`; `IntersectionObserver` scroll reveal → `visibility_detector` + `flutter_animate` (never a global scroll listener); `backdrop-blur` → `BackdropFilter` in `ClipRRect`, fixed elements only; tabular figures → `FontFeature.tabularFigures()`; bento → `LayoutBuilder` + staggered grid collapsing to single column.

**Pre-flight taste check (per screen):** design read stated · brand font is Be Vietnam Pro · numerics use tabular figures · no banned defaults · VN strings tested at +40% length (no clipping) · operational surfaces MOTION ≤ 2 and add zero tap delay · double-bezel/expressive motion only on dashboard/onboarding · diffuse+hairline elevation, dark-mode parity · reduced-motion respected · reads as a deliberately designed product, not "M3 default with nice colors."

---

## PART 4 — Lo-Fi Wireframes

Wireframe the whole ecosystem: Splash · Login/Auth · Dashboard · POS Terminal · Product List · Product Details · Stock Inbound · Stock Outbound · Inventory · Invoices/Transaction History · Customer Management · Reports/Analytics · AI Assistant Chat · AI Inventory Smart Panel · System Settings · plus Onboarding wizard, Returns, Shift open/close, and (F&B) Table management. Focus on UX flows, spacing, structural layout.

---

## PART 5 — Hi-Fi UI

Transform every wireframe into hi-fi: modern, premium, minimalist; strict M3; fully responsive across form factors; visually striking 16px-radius cards; subtle fluid micro-animations; Web/Tablet/Android/iPhone compliant. **Gate each screen's variance/motion/density by the Part 3.5 table** — not one global "premium" setting. Apply nested-card and expressive motion to Dashboard/Onboarding only. Deliver an original, bespoke design that copies no existing product.

---

## PART 6 — Sales Screen / Trang bán hàng (detailed)

Models the Vietnamese sales-management pattern (KiotViet/Sapo register UX). Dials for this surface: **VARIANCE 3 · MOTION 2 · DENSITY 7** — no interaction may add delay to a tap.

### 6.A Multi-Invoice Tabs / Nhiều hóa đơn cùng lúc
* Top tab strip: `Đơn 1`, `Đơn 2`, `Đơn 3` … + `+` New order / Thêm hóa đơn.
* Each tab = isolated state (cart, customer, price list, discounts, notes); item-count badge; instant switch.
* Close `×` confirms only if non-empty. Persist all open tabs locally (offline-first); each order carries an offline-safe ID reconciled on sync. Sensible cap (~10–20) with a clear limit message.

### 6.B Price List Selection / Chọn bảng giá
* Per-invoice dropdown `Bảng giá ▾`: Retail / Giá bán lẻ, Wholesale / Giá sỉ, VIP / Giá VIP, + custom books from Settings.
* Selecting re-prices the whole cart (lines with manual overrides from 6.D are preserved or flagged with a confirm). Attaching a customer tier may auto-select their default price list (still overridable). Each open invoice may use a different price list.

### 6.C Search/Scan-Driven Left Panel — No Default Product Grid / Không hiện sẵn sản phẩm
* Input-first: large always-focused search + barcode/QR scanner; scanned matches auto-add to the active cart.
* Results appear only as the user types/scans (a result list, not a persistent grid).
* Empty state hint: `Scan or search to add an item / Quét mã hoặc tìm sản phẩm để thêm` + optional Recent / Hàng vừa bán and Quick items / Bán nhanh chips.
* Setting toggle `Show product grid / Hiện lưới sản phẩm: Off` (default Off; On for browse-heavy verticals, driven by Part 2). Grid hidden ⇒ cart area widens.

### 6.D Tap a Line to Edit — Price Override + Per-Item Discount / Sửa giá & giảm giá từng sản phẩm
Cart is a dense tabular order list. Tapping a line opens an inline editor (popover; bottom sheet on mobile).
* **Columns:** Product / Sản phẩm (name+SKU) · Unit / ĐVT (6.E) · Qty / SL (±and direct entry) · Unit price / Đơn giá (editable) · Discount / Giảm giá (`%`/`đ`) · Line total / Thành tiền.
* **Price override:** editing replaces the price-list price for that line in that invoice only; mark it visually (dot / struck original). RBAC-gated (Part 20: Manager role or PIN, configurable); logged to audit (who/when/old→new).
* **Discount:** toggle `% | đ` per line (% off, or fixed VND off); show original → discount → line total. **Order-level discount** also in the summary, applied after line discounts. Same RBAC/audit gating; optional max-discount ceiling per role.

### 6.E Switch Unit of Measurement / Đổi đơn vị tính
* Products define multiple units with conversion factors (Part 7), e.g., Lon → Lốc (×6) → Thùng (×24).
* Per-line **ĐVT** dropdown; switching recomputes unit price (price-list or unit-specific) and stock deduction by factor (1 Thùng = 24 base units). Line remembers chosen unit; missing unit price falls back to base×factor and is flagged.

### 6.F Right Summary & Checkout (≤ 3 actions)
* Summary: Subtotal / Tạm tính · line discounts · order discount (%/đ) · VAT (Part 13) · **Total / Tổng cộng** · Paid / Khách trả + Change / Tiền thối.
* Payments (Part 14): Cash / Tiền mặt, VietQR, e-wallet, Card, split payment.
* Post-purchase (Parts 13/15): Print + transmit e-invoice / In hóa đơn · Share / Chia sẻ (SMS/Zalo/Email) · Save order / Giữ giỏ hàng.
* **3-action target:** known-SKU sale = (1) scan, (2) tap payment, (3) confirm. All power-features above are optional and must not slow this path.

---

## PART 7 — Product Management

Each product profile: SKU · Barcode · QR · Name / Tên sản phẩm · Image gallery · Cost price / Giá vốn · **Multi-level selling prices per price book** (retail/wholesale/VIP/custom) · Category / Danh mục · Supplier / Nhà cung cấp · **Multiple units with conversion factors** / Đơn vị tính · Current stock / Tồn kho hiện tại · Minimum stock / Tồn tối thiểu (safety-stock alert) · **Tax rate** (Part 13) · optional **expiry/batch** (grocery/cosmetics) · price-by-weight flag · Status / Trạng thái (Active/Draft/Archived).

Support advanced global search, multi-layered filtering, inline quick edits, and **bulk import** (Part 22). Allow the data model to expand to variants (color/size/attributes) per industry.

---

## PART 8 — Inventory Management

Features: Stock Inbound / Nhập hàng · Stock Outbound / Xuất hàng · **Internal-Use Issue / Xuất dùng nội bộ** (8.1) · Stock Adjustment / Điều chỉnh tồn · Stocktaking / Kiểm kho · Transaction Logs / Nhật ký kho (audit trail).

### 8.1 Internal-Use Issue / Xuất dùng nội bộ
A dedicated goods-issue document for stock consumed **internally, not sold** — distinct from a sale, from a damage/expiry write-off, and from a stock adjustment.

* **Purpose / Lý do (reason codes):** staff use / Dùng cho nhân viên · samples & marketing / Hàng mẫu, tiếp thị · store consumables / Vật tư tiêu hao tại cửa hàng · display / Trưng bày · gift/promo / Quà tặng, khuyến mãi · testing/R&D / Hàng thử nghiệm · transfer-out other / Khác. Reason list is configurable in Settings.
* **Document fields / Phiếu xuất:** issue No. + date · item lines (product, **unit/ĐVT with conversion**, quantity) · reason code · receiver/department / Người/Bộ phận nhận · note / Ghi chú · optional attachment/photo · warehouse/branch (future multi-warehouse, Part 12).
* **Stock & cost / Tồn & chi phí:** deducts on-hand by the unit-conversion factor (Part 6.E logic) and values the issue at **cost price / giá vốn** → recorded as a **cost/expense, no revenue, no sales invoice**. Surface the total internal-use value per document. Make VAT/tax treatment of internal-use goods **configurable** (some cases may require an output document) — design the hook, defer specifics to the certified provider (Part 13).
* **Control / Kiểm soát:** RBAC-gated (Part 20) — issuing and approving may require Manager role or PIN; optional approval step for high-value issues; every issue written to the audit trail (who/what/when/which device) and to Transaction Logs.
* **Offline / Ngoại tuyến:** allowed offline; queued and reconciled on sync, stock server-authoritative (Part 19).
* **Entry points / Lối vào:** primarily the Inventory module; for F&B also reachable from POS as a comp/staff-meal/wastage shortcut (Part 18) that posts an internal-use issue rather than a sale.
* **Reporting / Báo cáo:** internal-use value over a period, broken down by reason and by department/receiver; included in inventory-movement reports and feeds Part 11 cost analytics. Export PDF/Excel.

Dashboard widgets: Total inventory value / Tổng giá trị tồn kho · Low-stock alerts / Sắp hết hàng · Stagnant stock / Tồn kho lâu ngày · Slow-moving items / Hàng bán chậm · **Internal-use cost (period) / Chi phí dùng nội bộ (kỳ)**. Keep visualizations clean, intuitive, actionable.

---

## PART 9 — AI Assistant

Embedded conversational assistant for natural-language queries (bilingual, accent-insensitive), e.g.: "How much did we sell today? / Hôm nay bán được bao nhiêu?", "Top best-sellers? / Mặt hàng nào bán chạy nhất?", "What's slow-moving / sitting too long / running low?", "What should I restock today? / Hôm nay nên nhập thêm hàng gì?". Responds with NLP + interactive tables/charts.

**Safety & accuracy (mandatory):** answers must be **grounded in the store's actual data** (retrieval over sales/inventory/customers), never fabricated. When data is missing/ambiguous, say so rather than invent numbers; every numeric claim links to a source view. Any side-effectful action (e.g., creating a PO) requires explicit user confirmation. Define on-device vs cloud processing and disclose it; respect PDPL consent (Part 13) for any customer data sent to a cloud model. Graceful fallback to deterministic reports when AI is unavailable.

---

## PART 10 — AI Inventory Smart Restocking

Engine: analyze historical sales + seasonality → average daily sales velocity → forecast remaining "Days of Stock" → smart restock quantity → priority **High (Cao) / Medium (Trung bình) / Low (Thấp)**.

Bilingual interactive table: Product / Sản phẩm · Current stock / Tồn hiện tại · Avg daily velocity / Tốc độ bán TB ngày · Est. days of stock / Số ngày đủ bán dự kiến · AI suggested qty / Đề xuất số lượng nhập từ AI · Priority badge / Mức độ ưu tiên.

Controls: Generate PO / Tạo phiếu nhập hàng (explicit confirm) · Manual override / Chỉnh sửa nhanh (show assumptions) · Export PDF / Xuất PDF · Export Excel / Xuất Excel. Never auto-execute a PO.

---

## PART 11 — Executive Dashboard & Analytics

KPIs (bilingual): Today's / Weekly / Monthly revenue (Doanh thu hôm nay/tuần/tháng) · Net profit margin / Lợi nhuận ròng · Top products / Top sản phẩm bán chạy · Slow-moving dead stock / Hàng bán chậm · Low-stock critical alerts / Cảnh báo tồn kho nguy hiểm · AI insights / Phân tích từ AI (e.g., "Sales increased 15% / Doanh số tăng 15%").

Charts: revenue trend lines (dual legend "Revenue / Doanh thu") · profit-margin distribution · inventory turnover · forecast/velocity trends (bilingual axes "Jan / Thg 1"…). All widgets support drag-and-drop layout customization. Apply the dashboard dial profile (Part 3.5).

---

## PART 12 — Flutter Developer Handoff

Deliver: feature-first directory structure · clean-architecture domain layers · reusable UI component map · native M3 widget mappings · responsive strategy (LayoutBuilder, breakpoints) · design-token conversion maps (colors/spacing/type via `AppTokens`) · motion curves · accessibility & localization (Intl/`intl`, Semantics, min contrast). Strict, unambiguous handoff package.

**Cleanly isolated adapter layers for future swap/scale:** offline-sync layer (Part 19) · peripheral abstraction (Part 15) · payments adapter (Part 14) · e-invoice/tax provider adapter (Part 13). Plus scaling blueprint for: multi-branch & multi-warehouse · advanced CRM · voucher/promotion engines · loyalty · predictive AI · real-time cloud sync · granular RBAC.

---

## PART 13 — Vietnamese Compliance, Tax & E-Invoicing (hard requirement)

* **E-invoice from cash register / Hóa đơn điện tử khởi tạo từ máy tính tiền:** generated from the POS and transmitted to the tax authority (Decree 70/2025/NĐ-CP amending Decree 123/2020, effective 01/6/2025; Circular 32/2025/TT-BTC replacing Circular 78/2021). Applies to household/individual businesses with annual revenue ≥ 1 billion VND, retail, F&B, hospitality, transport, entertainment — make it configurable per store at onboarding. Generate the tax-authority code (prefix "M") + buyer QR/lookup. Offline: queue and reconcile on reconnect while still printing a valid receipt at sale time.
* **Tax / Thuế GTGT:** per-item VAT rates (0/5/8/10%), tax-inclusive vs exclusive, tax summary on receipts; tax-invoice vs sales-receipt distinction; capture buyer tax info (company, MST, address) on demand.
* **Data privacy / Bảo vệ dữ liệu cá nhân (CRM):** comply with the PDPL (Law 91/2025/QH15, effective 01/01/2026; Decree 356/2025/NĐ-CP — replacing Decree 13/2023). Explicit, granular, revocable consent; purpose limitation & minimization; per-customer consent state; data export/delete controls; 72-hour breach-notification readiness. Apply small-business transitional exemptions where relevant but keep the stricter path available.

*Design the mechanism; let operators plug in a certified e-invoice/tax provider. This is a design requirement, not legal advice.*

---

## PART 14 — Payments Integration (Vietnam-first)

Methods: Cash / Tiền mặt (change calculator) · Bank QR via VietQR/Napas / Quét mã VietQR (dynamic QR with exact amount + order ref) · e-wallets / Ví (MoMo, ZaloPay, VNPay) · Cards / Thẻ (mPOS/SoftPOS) · split payment / thanh toán nhiều phương thức.

Reconciliation: payment states (pending/confirmed/failed/timeout/refunded); webhook/callback handling for async QR & wallet with clear cashier-facing states; end-of-day settlement matching gateway totals to sales. Treat confirmation as irreversible — explicit confirm, never auto-finalize on ambiguous network states.

---

## PART 15 — Hardware & Peripheral Integration

Hardware abstraction layer + UX for: thermal printer 58/80mm / Máy in nhiệt (failure recovery + reprint) · barcode/QR scanner / Máy quét (wedge + camera) · cash drawer / Ngăn kéo tiền · customer display / Màn hình cho khách · weighing scale / Cân điện tử (price-by-weight) · card reader / mPOS. Device pairing & status UI; every hardware path has a manual fallback; receipt template customization (logo, header/footer, tax block, e-invoice QR).

---

## PART 16 — Returns, Refunds & Exchanges

Flows: Return / Trả hàng (full/partial, reason codes) · Refund / Hoàn tiền (to original method where possible) · Exchange / Đổi hàng (with price-difference settlement) · link to original invoice + restock-vs-write-off decision. Edge cases: network loss mid-transaction; payment confirmed but receipt not printed; duplicate-scan/double-charge prevention (idempotency); void in-progress order; manager-approval gating for high-value voids/refunds.

---

## PART 17 — Shift & Cash Management

Open shift / Mở ca (opening float / Tiền đầu ca) · Close shift / Đóng ca (cash count & reconciliation, expected vs counted, variance / Chênh lệch) · cash in/out / Thu chi tiền mặt · per-shift & per-cashier summary · handover · manager view of all open shifts across devices.

---

## PART 18 — Food & Beverage Vertical (industry-toggled)

Table management / Quản lý bàn (floor map, status, move/merge) · Order to kitchen / Chuyển bếp (KOT / Phiếu bếp, KDS) · course timing & modifiers / Tùy chọn món ("ít đường / no ice") · split bill / Tách hóa đơn & merge / Gộp hóa đơn (per-seat or even) · open tab / Mở bàn vs immediate checkout. Appears only for F&B stores (Part 2).

---

## PART 19 — Offline-First Sync Architecture

Local-first store + durable outbox/sync queue · per-entity conflict resolution (last-write-wins for simple fields; server-authoritative for stock & money) · idempotency keys on every mutating op · offline-safe ID generation (UUID/ULID) reconciled on sync · sync-status UI (pending badge, last-synced, manual sync, conflict review). Define what's allowed offline (sell, print, hold) vs requires connectivity (e-invoice transmission, card auth).

---

## PART 20 — Security, Authentication & RBAC

Login / Đăng nhập: PIN, biometric, password (admin) · quick cashier switch on shared terminals · session timeout/auto-lock · re-auth for sensitive actions (refunds, price overrides, settings) · granular RBAC / Phân quyền (Owner, Manager, Cashier, Stock-keeper, Accountant; permission matrix per module/action) · audit log / Nhật ký thao tác (who/what/when/which device) · device trust + remote sign-out.

---

## PART 21 — Onboarding, Store Setup & Data Migration

Store-creation wizard / Trình tạo cửa hàng (industry → module toggles, currency/locale, tax + e-invoice provider, receipt branding) · guided setup checklist · data import / Nhập dữ liệu from Excel/CSV and KiotViet/Sapo/POS365 (field mapping, validation, dry-run preview before commit) · demo/sample-data mode.

---

## PART 22 — Success Metrics, Analytics & Telemetry

North-star metric + KPIs (activation, time-to-checkout, DAU stores, retention). Operational targets: ≤3-action checkout (Part 6), p95 screen-load and scan-to-cart latency budgets, crash-free rate, sync-success rate. Product analytics + crash/error monitoring, privacy-respecting (no PII in event payloads; PDPL-aligned).

---

## PART 23 — QA, Usability Testing & Accessibility

Usability testing of the high-frequency cashier flow under realistic conditions (speed, noise, gloves, glare). WCAG 2.1 AA: contrast, large touch targets for tablet POS, screen-reader semantics, scalable text surviving EN↔VI length changes. Bilingual QA (no clipping/overflow across components & form factors). Test matrix across Web/Tablet/Android/iPhone; offline↔online transition tests; edge-case scripts for Part 16.

---

## PART 24 — Notifications & Alerts

Channels: in-app, push, optional email/Zalo for owners. Alert types: low stock / sắp hết hàng, stagnant stock, shift variance, sync failure, daily sales summary, AI restock recommendations. User-configurable thresholds + quiet hours; role-based routing.

---

## PART 25 — Post-Build Execution Checklist

* Generate a clickable, fully interactive prototype.
* Audit the whole UX to eliminate redundant clicks/friction.
* Keep the high-speed checkout frictionless and consistent across Web/Tablet/Mobile.
* Prioritize long-term enterprise scalability while staying clean and accessible for solo operators.
* Run the Part 3.5 pre-flight taste check on every screen before shipping.

---

*Note: legal/tax/data-protection items describe mechanisms LumaPOS must support, sourced from current Vietnamese regulation (Decree 70/2025, Circular 32/2025, PDPL 91/2025 & Decree 356/2025). They are design requirements, not legal advice — connect a certified provider and confirm obligations with a qualified advisor.*
