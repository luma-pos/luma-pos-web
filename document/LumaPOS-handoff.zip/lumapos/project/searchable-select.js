// LumaPOS — SearchableSelect
// Global reusable component. Exported to window.SearchableSelect
// Part 3 global showSearch rule: auto-enabled when options.length >= threshold (default 8)
// Vietnamese accent-insensitive: "bao ve" matches "Bảo vệ"
// Options shape: { value, label, labelVI?, code? }

(function () {
  const { useState, useEffect, useRef } = React;

  /* ── inject styles once ── */
  if (!document.getElementById('__ss_styles')) {
    const st = document.createElement('style');
    st.id = '__ss_styles';
    st.textContent = `
.ss-wrap{position:relative;}
.ss-trigger{
  width:100%;padding:9px 11px;background:var(--cv);border:1.5px solid var(--bd);
  border-radius:var(--rsm);font-size:13px;color:var(--t1);font-family:var(--font);
  cursor:pointer;display:flex;align-items:center;justify-content:space-between;
  gap:6px;text-align:left;transition:border-color .15s,box-shadow .15s;line-height:1.4;
  min-height:38px;
}
.ss-trigger:hover{border-color:var(--ac);}
.ss-trigger:focus{outline:none;border-color:var(--ac);box-shadow:0 0 0 3px var(--acb);}
.ss-trigger:disabled{opacity:.5;cursor:not-allowed;pointer-events:none;}
.ss-val{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:13px;min-height:18px;}
.ss-sub-val{font-size:10px;color:var(--t2);font-style:italic;margin-left:5px;font-weight:400;}
.ss-chev{flex-shrink:0;opacity:.4;transition:transform .15s;}
.ss-chev.open{transform:rotate(180deg);}
.ss-panel{
  position:absolute;top:calc(100% + 4px);left:0;right:0;min-width:200px;
  background:var(--sf);border-radius:13px;
  box-shadow:0 8px 32px rgba(0,0,0,.12),0 2px 8px rgba(0,0,0,.05),0 0 0 1px var(--bd);
  z-index:1200;overflow:hidden;
  animation:ssIn .12s cubic-bezier(.16,1,.3,1) both;
  max-height:292px;overflow-y:auto;
}
@keyframes ssIn{from{opacity:0;transform:translateY(-4px) scale(.98);}to{opacity:1;transform:none;}}
@media(prefers-reduced-motion:reduce){.ss-panel{animation:none;}}
.ss-search-row{
  display:flex;align-items:center;gap:7px;padding:8px 11px;
  border-bottom:1px solid var(--bd);position:sticky;top:0;background:var(--sf);z-index:1;
}
.ss-inp{flex:1;border:none;background:transparent;font-family:var(--font);font-size:12px;color:var(--t1);outline:none;}
.ss-inp::placeholder{color:var(--t3);}
.ss-xclear{background:none;border:none;cursor:pointer;color:var(--t3);font-size:16px;padding:0;line-height:1;width:18px;text-align:center;}
.ss-glabel{padding:7px 12px 3px;font-size:9px;font-weight:700;color:var(--t3);text-transform:uppercase;letter-spacing:.06em;}
.ss-hdiv{height:1px;background:var(--bd);margin:4px 0;}
.ss-opt{
  display:flex;align-items:center;width:100%;padding:8px 12px;
  background:transparent;border:none;font-family:var(--font);font-size:12px;
  color:var(--t1);cursor:pointer;text-align:left;gap:8px;transition:background .08s;
}
.ss-opt:hover,.ss-opt.ss-foc{background:var(--sf2);}
.ss-opt.ss-sel{color:var(--act);}
.ss-olabel{flex:1;}
.ss-osub{font-size:10px;color:var(--t2);font-style:italic;display:block;margin-top:1px;}
.ss-chk{color:var(--ac);font-size:13px;font-weight:700;flex-shrink:0;}
.ss-empty{padding:18px 12px;font-size:11px;color:var(--t3);text-align:center;font-style:italic;}
    `;
    document.head.appendChild(st);
  }

  /* ── Vietnamese accent normalizer ── */
  function normalizeVI(s) {
    if (!s) return '';
    return String(s)
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[đĐ]/g, m => m === 'đ' ? 'd' : 'D')
      .toLowerCase();
  }

  /* ── SearchableSelect ── */
  function SearchableSelect({
    options    = [],   // [{value, label, labelVI?, code?}]
    value,
    onChange,
    placeholder   = 'Select…',
    placeholderVI = 'Chọn…',
    showSearch    = 'auto', // 'auto' | true | false
    threshold     = 8,
    recent        = [],    // array of values to show in "Recent" group
    lang          = 'en',
    disabled      = false,
    style         = {},
  }) {
    const [open,   setOpen]   = useState(false);
    const [query,  setQuery]  = useState('');
    const [focIdx, setFocIdx] = useState(-1);
    const wrapRef  = useRef(null);
    const inputRef = useRef(null);

    const L       = lang === 'vi';
    const doSearch = showSearch === true || (showSearch === 'auto' && options.length >= threshold);

    /* filter */
    const q = normalizeVI(query);
    const filtered = q
      ? options.filter(o =>
          normalizeVI(o.label).includes(q) ||
          normalizeVI(o.labelVI || '').includes(q) ||
          normalizeVI(o.code || '').includes(q))
      : options;

    /* recent group (top 3, only when no query) */
    const recentOpts = (recent.length && !q)
      ? options.filter(o => recent.includes(o.value)).slice(0, 3)
      : [];

    const allItems = [...recentOpts, ...filtered];
    const selOpt   = options.find(o => o.value === value);

    /* focus search input on open */
    useEffect(() => {
      if (open) {
        setQuery(''); setFocIdx(-1);
        if (doSearch) setTimeout(() => inputRef.current?.focus(), 20);
      }
    }, [open]);

    /* close on outside click */
    useEffect(() => {
      const fn = e => {
        if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
      };
      document.addEventListener('mousedown', fn);
      return () => document.removeEventListener('mousedown', fn);
    }, []);

    const handleKey = e => {
      if (!open) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setOpen(true); }
        return;
      }
      if (e.key === 'Escape') { setOpen(false); return; }
      if (e.key === 'ArrowDown') { e.preventDefault(); setFocIdx(i => Math.min(i + 1, allItems.length - 1)); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); setFocIdx(i => Math.max(i - 1, 0)); }
      else if (e.key === 'Enter' && focIdx >= 0) { onChange(allItems[focIdx]?.value); setOpen(false); }
    };

    const pick = v => { onChange(v); setOpen(false); };

    return (
      <div ref={wrapRef} className="ss-wrap" style={style}>
        <button
          type="button"
          className="ss-trigger"
          onClick={() => !disabled && setOpen(o => !o)}
          onKeyDown={handleKey}
          disabled={disabled}
          aria-haspopup="listbox"
          aria-expanded={open}
        >
          <span className="ss-val">
            {selOpt
              ? (L && selOpt.labelVI
                  ? <>{selOpt.labelVI}<span className="ss-sub-val">{selOpt.label}</span></>
                  : selOpt.label)
              : <span style={{color:'var(--t3)'}}>{L ? placeholderVI : placeholder}</span>}
          </span>
          <svg className={`ss-chev${open?' open':''}`} width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M6 9l6 6 6-6"/>
          </svg>
        </button>

        {open && (
          <div className="ss-panel" role="listbox">
            {doSearch && (
              <div className="ss-search-row">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                  <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
                </svg>
                <input
                  ref={inputRef}
                  className="ss-inp"
                  placeholder={L ? 'Tìm kiếm…' : 'Search…'}
                  value={query}
                  onChange={e => { setQuery(e.target.value); setFocIdx(-1); }}
                  onKeyDown={handleKey}
                />
                {query && <button className="ss-xclear" onClick={() => setQuery('')}>×</button>}
              </div>
            )}

            {recentOpts.length > 0 && (
              <>
                <div className="ss-glabel">{L ? 'Gần đây' : 'Recent'}</div>
                {recentOpts.map((opt, i) => (
                  <button key={`r-${opt.value}`}
                    className={`ss-opt${opt.value===value?' ss-sel':''}${focIdx===i?' ss-foc':''}`}
                    onClick={() => pick(opt.value)} role="option" aria-selected={opt.value===value}>
                    <span className="ss-olabel">
                      {L && opt.labelVI ? opt.labelVI : opt.label}
                      {opt.labelVI && <span className="ss-osub">{L ? opt.label : opt.labelVI}</span>}
                    </span>
                    {opt.value === value && <span className="ss-chk">✓</span>}
                  </button>
                ))}
                {filtered.length > 0 && <div className="ss-hdiv"/>}
              </>
            )}

            {filtered.length === 0
              ? <div className="ss-empty">{L ? 'Không tìm thấy kết quả' : 'No results found'}</div>
              : filtered.map((opt, i) => {
                  const idx = recentOpts.length + i;
                  return (
                    <button key={opt.value}
                      className={`ss-opt${opt.value===value?' ss-sel':''}${focIdx===idx?' ss-foc':''}`}
                      onClick={() => pick(opt.value)} role="option" aria-selected={opt.value===value}>
                      <span className="ss-olabel">
                        {L && opt.labelVI ? opt.labelVI : opt.label}
                        {opt.labelVI && <span className="ss-osub">{L ? opt.label : opt.labelVI}</span>}
                      </span>
                      {opt.value === value && <span className="ss-chk">✓</span>}
                    </button>
                  );
                })
            }
          </div>
        )}
      </div>
    );
  }

  Object.assign(window, { SearchableSelect, normalizeVI });
})();
