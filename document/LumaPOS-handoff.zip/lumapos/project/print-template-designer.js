// LumaPOS — Part 15.1 Print Template Designer
// Exported to window.PrintTemplatesSection
// Document types × paper sizes (K80/K57/A5/A4), live preview, column toggles,
// drag-reorder, bilingual print, placeholder tokens, per-type saved templates.

(function () {
  const { useState, useCallback, useRef } = React;

  /* ── constants ── */
  const DOC_TYPES = [
    { id:'invoice',        en:'Sales Invoice',          vi:'Hóa đơn bán hàng',        ico:'🧾' },
    { id:'goods-receipt',  en:'Goods Receipt (Inbound)',vi:'Phiếu nhập hàng',          ico:'📥' },
    { id:'purchase-order', en:'Purchase Order',          vi:'Phiếu đặt hàng (NCC)',    ico:'📋' },
    { id:'quotation',      en:'Quotation',               vi:'Báo giá',                  ico:'📄' },
    { id:'internal-issue', en:'Internal-Use Issue',      vi:'Phiếu xuất nội bộ',       ico:'📤' },
    { id:'stock-outbound', en:'Stock Outbound',          vi:'Phiếu xuất hàng',          ico:'🚚' },
    { id:'stock-transfer', en:'Stock Transfer',          vi:'Phiếu chuyển kho',         ico:'🔄' },
    { id:'return-slip',    en:'Return Slip',             vi:'Phiếu trả hàng',           ico:'↩' },
    { id:'stocktake',      en:'Stocktake Sheet',         vi:'Phiếu kiểm kho',           ico:'📊' },
    { id:'shift-report',   en:'Shift Report (X/Z)',      vi:'Báo cáo ca (X/Z)',         ico:'📈' },
  ];

  const PAPER_SIZES = [
    { id:'K80', label:'K80', sub:'80mm thermal', canvasW:220, canvasH:null,  thermal:true  },
    { id:'K57', label:'K57', sub:'58mm thermal', canvasW:170, canvasH:null,  thermal:true  },
    { id:'A5',  label:'A5',  sub:'148×210mm',    canvasW:420, canvasH:595,   thermal:false },
    { id:'A4',  label:'A4',  sub:'210×297mm',    canvasW:595, canvasH:842,   thermal:false },
  ];

  const DEFAULT_COLS = [
    { id:'no',       en:'No.',       vi:'STT',         enabled:true  },
    { id:'sku',      en:'SKU',       vi:'SKU',         enabled:false },
    { id:'name',     en:'Product',   vi:'Tên sản phẩm',enabled:true  },
    { id:'unit',     en:'Unit',      vi:'ĐVT',         enabled:true  },
    { id:'qty',      en:'Qty',       vi:'SL',          enabled:true  },
    { id:'price',    en:'Unit Price',vi:'Đơn giá',     enabled:true  },
    { id:'discount', en:'Discount',  vi:'Giảm giá',    enabled:false },
    { id:'vat',      en:'VAT',       vi:'Thuế GTGT',   enabled:false },
    { id:'total',    en:'Line Total',vi:'Thành tiền',  enabled:true  },
  ];

  const TOKENS = [
    '{{store.name}}','{{store.address}}','{{store.phone}}','{{store.tax_id}}','{{store.website}}',
    '{{doc.no}}','{{doc.date}}','{{doc.type}}',
    '{{customer.name}}','{{customer.phone}}','{{customer.tax_id}}',
    '{{items}}','{{subtotal}}','{{discount}}','{{vat}}','{{total}}','{{paid}}','{{change}}',
    '{{cashier.name}}','{{shift.no}}','{{branch.name}}',
  ];

  /* sample data for live preview */
  const S = {
    storeName:'Cửa hàng Nguyễn Hoa', address:'12 Nguyễn Trãi, Cầu Giấy, Hà Nội',
    phone:'0912 345 678', taxId:'0123456789', website:'lumapos.vn',
    docNo:'HD-20260614-0892', date:'14/06/2026  09:31',
    customer:'Khách lẻ / Walk-in', cashier:'Phạm Thùy Linh',
    items:[
      { no:1,sku:'SP001',name:'Sữa Vinamilk 180ml', unit:'Hộp',qty:3, price:'6.500', discount:'—', vat:'10%',total:'19.500' },
      { no:2,sku:'SP045',name:'Mì Hảo Hảo 75g',     unit:'Gói',qty:5, price:'4.200', discount:'—', vat:'10%',total:'21.000' },
      { no:3,sku:'SP112',name:'Bia Tiger 330ml',     unit:'Lon', qty:6, price:'13.500',discount:'5%',vat:'10%',total:'76.950' },
    ],
    subtotal:'117.450', vat:'11.745', total:'117.450', paid:'120.000', change:'2.550',
  };

  function makeTpl(docType='invoice', paperSize='K80', name='Default') {
    return {
      id:`t${Date.now()}${Math.random().toString(36).slice(2,6)}`,
      docType, paperSize, name, isDefault:false, lang:'both',
      header:{ logo:true, storeName:true, address:true, phone:true, taxId:false, website:false },
      docTitle:{ show:true, docNo:true, titleOverride:'' },
      columns:DEFAULT_COLS.map(c=>({...c})),
      footer:{
        thankYou:true, thankYouText:'Cảm ơn quý khách! / Thank you!',
        sigBuyer:false, sigSeller:true, sigWarehouse:false,
        paymentBank:false, vietQR:false, eInvoiceQR:false, taxBlock:false,
      },
    };
  }

  const SEED_TEMPLATES = [
    { ...makeTpl('invoice','K80','K80 Compact'),       id:'s1', isDefault:true  },
    { ...makeTpl('invoice','A4','A4 Detailed'),         id:'s2', footer:{...makeTpl().footer,sigSeller:true,eInvoiceQR:true,taxBlock:true}, columns:DEFAULT_COLS.map(c=>({...c,enabled:true})) },
    { ...makeTpl('goods-receipt','A4','Goods Receipt'), id:'s3', isDefault:true  },
    { ...makeTpl('purchase-order','A4','PO Standard'), id:'s4', isDefault:true  },
    { ...makeTpl('quotation','A4','Quotation A4'),      id:'s5', isDefault:true  },
  ];

  /* ── tiny Toggle ── */
  function Tog({on,onChange}){
    return (
      <button className={`tog${on?' on':''}`} onClick={()=>onChange(!on)}>
        <div className="tok"/>
      </button>
    );
  }

  /* ── Live Preview ── */
  function LivePreview({ tpl, L }) {
    const sz      = PAPER_SIZES.find(s=>s.id===tpl.paperSize) || PAPER_SIZES[0];
    const thermal = sz.thermal;
    const PREVIEW_W = 272;
    const scale   = PREVIEW_W / sz.canvasW;
    const enabledCols = tpl.columns.filter(c=>c.enabled);
    const lm      = tpl.lang; // 'en'|'vi'|'both'

    const txt = (en,vi) => {
      if (lm==='en') return en;
      if (lm==='vi') return vi;
      return <>{vi}<span style={{fontSize:thermal?6:9,opacity:.55,marginLeft:3,fontStyle:'italic'}}>{en}</span></>;
    };

    const dt        = DOC_TYPES.find(d=>d.id===tpl.docType)||DOC_TYPES[0];
    const titleText = tpl.docTitle.titleOverride || (lm==='en'?dt.en:lm==='vi'?dt.vi:`${dt.vi} / ${dt.en}`);
    const pPad      = thermal ? 8 : 28;
    const bsz       = thermal ? 9  : 11;
    const docH      = sz.canvasH ? sz.canvasH : 'auto';

    const HR = ({dashed=false})=>(
      <div style={{borderTop:`${dashed?'1px dashed #bbb':thermal?'1px solid #333':'1.5px solid #111'}`,margin:`${thermal?4:8}px 0`}}/>
    );

    const cellAlign = id => ['total','price','qty'].includes(id)?'right':'left';

    return (
      <div style={{width:PREVIEW_W,overflow:'hidden'}}>
        <div style={{
          width:sz.canvasW, minHeight:docH||undefined,
          transform:`scale(${scale})`, transformOrigin:'top left',
          background:'#fff', fontFamily:thermal?"'Courier New',monospace":"'Be Vietnam Pro',sans-serif",
          fontSize:bsz, color:'#111', padding:pPad, boxSizing:'border-box', lineHeight:1.5,
          boxShadow:'0 2px 20px rgba(0,0,0,.14)',
        }}>

          {/* ── HEADER ── */}
          {(tpl.header.logo||tpl.header.storeName||tpl.header.address||tpl.header.phone||tpl.header.taxId) && (
            <div style={{display:'flex',flexDirection:thermal?'column':'row',alignItems:thermal?'center':'flex-start',gap:thermal?4:12,marginBottom:thermal?6:14}}>
              {tpl.header.logo&&(
                <div style={{width:thermal?38:52,height:thermal?38:52,background:'#0C7B6B',borderRadius:thermal?6:10,display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontWeight:900,fontSize:thermal?14:20,flexShrink:0,alignSelf:thermal?'center':'flex-start'}}>L</div>
              )}
              <div style={{flex:1,textAlign:thermal?'center':'left'}}>
                {tpl.header.storeName&&<div style={{fontWeight:900,fontSize:thermal?11:16,letterSpacing:thermal?'.01em':'-.02em'}}>{S.storeName}</div>}
                {tpl.header.address&&<div style={{fontSize:thermal?7.5:10,opacity:.65,marginTop:1}}>{S.address}</div>}
                {tpl.header.phone&&<div style={{fontSize:thermal?7.5:10,opacity:.65}}>{txt('Tel','ĐT')}: {S.phone}</div>}
                {tpl.header.taxId&&<div style={{fontSize:thermal?7.5:10,opacity:.65}}>MST: {S.taxId}</div>}
                {tpl.header.website&&<div style={{fontSize:thermal?7.5:10,opacity:.65}}>{S.website}</div>}
              </div>
            </div>
          )}

          <HR dashed={thermal}/>

          {/* ── DOC TITLE ── */}
          {tpl.docTitle.show&&(
            <div style={{textAlign:'center',marginBottom:thermal?5:10}}>
              <div style={{fontWeight:900,fontSize:thermal?11:15,textTransform:'uppercase',letterSpacing:'.04em'}}>{titleText}</div>
              {tpl.docTitle.docNo&&<div style={{fontSize:thermal?7.5:9.5,opacity:.55,marginTop:2}}>{txt('No.','Số')}: {S.docNo}</div>}
              <div style={{fontSize:thermal?7.5:9.5,opacity:.55}}>{txt('Date','Ngày')}: {S.date}</div>
              <div style={{fontSize:thermal?7.5:9.5,opacity:.55}}>{txt('Cashier','Thu ngân')}: {S.cashier}</div>
            </div>
          )}

          {thermal&&<HR dashed/>}

          {/* ── ITEMS ── */}
          {enabledCols.length>0&&(
            <div style={{marginBottom:thermal?5:10}}>
              {thermal ? (
                S.items.map((item,i)=>(
                  <div key={i} style={{marginBottom:3,paddingBottom:3,borderBottom:'1px dotted #ccc'}}>
                    <div style={{fontWeight:700,fontSize:9}}>{item.name}</div>
                    <div style={{display:'flex',justifyContent:'space-between',fontSize:7.5}}>
                      <span>{item.qty} × {item.price}</span>
                      <span style={{fontWeight:700}}>{item.total}</span>
                    </div>
                    {enabledCols.find(c=>c.id==='discount')&&item.discount!=='—'&&(
                      <div style={{fontSize:7,opacity:.6}}>{txt('Disc','Giảm')}: {item.discount}</div>
                    )}
                  </div>
                ))
              ) : (
                <table style={{width:'100%',borderCollapse:'collapse',fontSize:bsz-1}}>
                  <thead>
                    <tr style={{borderBottom:'1.5px solid #111'}}>
                      {enabledCols.map(col=>(
                        <th key={col.id} style={{padding:'3px 5px',textAlign:cellAlign(col.id),fontWeight:700,whiteSpace:'nowrap',fontSize:bsz-1}}>
                          {lm==='en'?col.en:lm==='vi'?col.vi:`${col.vi} / ${col.en}`}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {S.items.map((item,i)=>(
                      <tr key={i} style={{borderBottom:'1px solid #eee'}}>
                        {enabledCols.map(col=>(
                          <td key={col.id} style={{padding:'3px 5px',textAlign:cellAlign(col.id),fontFamily:['price','total','qty'].includes(col.id)?"'Courier New',monospace":'inherit'}}>
                            {col.id==='no'?item.no:col.id==='sku'?item.sku:col.id==='name'?item.name:col.id==='unit'?item.unit:col.id==='qty'?item.qty:col.id==='price'?item.price:col.id==='discount'?item.discount:col.id==='vat'?item.vat:col.id==='total'?item.total:'—'}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          )}

          {thermal&&<HR dashed/>}

          {/* ── TOTALS ── */}
          <div style={{marginBottom:thermal?5:8}}>
            {[
              [txt('Subtotal','Tạm tính'), S.subtotal, false],
              [txt('VAT (10%)','Thuế GTGT (10%)'), S.vat, false],
              [txt('TOTAL','TỔNG CỘNG'), S.total, true],
              [txt('Paid','Khách trả'), S.paid, false],
              [txt('Change','Tiền thối'), S.change, false],
            ].map(([label,val,bold],i)=>(
              <div key={i} style={{display:'flex',justifyContent:'space-between',fontWeight:bold?900:400,fontSize:bold?bsz+(thermal?1:2):bsz-1,borderTop:bold?(thermal?'1px solid #333':'1.5px solid #111'):'none',marginTop:bold?3:0,paddingTop:bold?3:0}}>
                <span>{label}</span>
                <span style={{fontFamily:"'Courier New',monospace"}}>{val}</span>
              </div>
            ))}
          </div>

          {/* ── FOOTER ── */}
          {thermal&&<HR dashed/>}
          {tpl.footer.thankYou&&(
            <div style={{textAlign:'center',fontSize:thermal?7.5:9.5,fontStyle:'italic',opacity:.7,marginBottom:thermal?4:8}}>{tpl.footer.thankYouText}</div>
          )}
          {(tpl.footer.sigBuyer||tpl.footer.sigSeller||tpl.footer.sigWarehouse)&&!thermal&&(
            <div style={{display:'flex',gap:10,marginTop:14,marginBottom:8}}>
              {tpl.footer.sigBuyer&&<div style={{flex:1,textAlign:'center',fontSize:8.5}}><div style={{fontWeight:700,marginBottom:22}}>{txt('Buyer','Người mua hàng')}</div><div style={{borderTop:'1px solid #999',paddingTop:3,opacity:.5,fontSize:7.5}}>(ký, ghi rõ họ tên)</div></div>}
              {tpl.footer.sigSeller&&<div style={{flex:1,textAlign:'center',fontSize:8.5}}><div style={{fontWeight:700,marginBottom:22}}>{txt('Seller','Người bán hàng')}</div><div style={{borderTop:'1px solid #999',paddingTop:3,opacity:.5,fontSize:7.5}}>(ký, ghi rõ họ tên)</div></div>}
              {tpl.footer.sigWarehouse&&<div style={{flex:1,textAlign:'center',fontSize:8.5}}><div style={{fontWeight:700,marginBottom:22}}>{txt('Warehouse','Thủ kho')}</div><div style={{borderTop:'1px solid #999',paddingTop:3,opacity:.5,fontSize:7.5}}>(ký, ghi rõ họ tên)</div></div>}
            </div>
          )}
          {tpl.footer.eInvoiceQR&&(
            <div style={{display:'flex',flexDirection:thermal?'column':'row',alignItems:'center',gap:6,marginTop:4}}>
              <div style={{width:thermal?50:60,height:thermal?50:60,border:'1px solid #ccc',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,alignSelf:thermal?'center':'flex-start'}}>
                <div style={{textAlign:'center',fontSize:thermal?7:8,color:'#999',lineHeight:1.3}}><div style={{fontSize:thermal?18:22}}>▦</div>e-invoice QR</div>
              </div>
              {!thermal&&<div style={{fontSize:8,opacity:.6,lineHeight:1.5}}><div style={{fontWeight:700}}>Tra cứu hóa đơn điện tử / E-Invoice</div><div>Mã: M{S.docNo.slice(3)}</div><div style={{fontSize:7}}>Decree 70/2025 · Circular 32/2025</div></div>}
            </div>
          )}
          {tpl.footer.vietQR&&(
            <div style={{display:'flex',alignItems:'center',gap:6,marginTop:4}}>
              <div style={{width:thermal?46:56,height:thermal?46:56,border:'1px solid #ccc',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                <div style={{textAlign:'center',fontSize:7,color:'#999',lineHeight:1.3}}><div style={{fontSize:thermal?16:20}}>▦</div>VietQR</div>
              </div>
              {!thermal&&<div style={{fontSize:8,opacity:.6}}><div style={{fontWeight:700}}>Thanh toán VietQR / VietQR Payment</div><div>Vietcombank ··· 0123 4567</div></div>}
            </div>
          )}
          {tpl.footer.taxBlock&&!thermal&&(
            <div style={{marginTop:8,border:'1px solid #ddd',borderRadius:4,padding:'6px 8px',fontSize:8,lineHeight:1.5}}>
              <div style={{fontWeight:700,marginBottom:2}}>Thông tin thuế GTGT / VAT Information</div>
              <div>Thuế suất / Rate: 10% · Giá trị tính thuế: {S.subtotal} ₫ · Thuế GTGT: {S.vat} ₫</div>
              <div style={{opacity:.6,marginTop:1}}>Người mua tự khai, tự nộp thuế (nếu có). Circular 32/2025/TT-BTC</div>
            </div>
          )}
        </div>
      </div>
    );
  }

  /* ── PrintTemplatesSection ── */
  function PrintTemplatesSection({ L }) {
    const [templates,    setTemplates]    = useState(SEED_TEMPLATES);
    const [activeDocType, setActiveDocType] = useState('invoice');
    const [activeTplId,  setActiveTplId]  = useState('s1');
    const [edTab,        setEdTab]        = useState('header');
    const [dragIdx,      setDragIdx]      = useState(null);
    const [showTokens,   setShowTokens]   = useState(false);

    const docTpls  = templates.filter(t=>t.docType===activeDocType);
    const activeTpl = templates.find(t=>t.id===activeTplId) || docTpls[0] || null;

    const upd = useCallback((id, fn) => {
      setTemplates(ts=>ts.map(t=>t.id===id?(typeof fn==='function'?fn(t):{...t,...fn}):t));
    },[]);

    const updH  = (f,v)=>upd(activeTpl.id,t=>({...t,header:{...t.header,[f]:v}}));
    const updFt = (f,v)=>upd(activeTpl.id,t=>({...t,footer:{...t.footer,[f]:v}}));
    const updDT = (f,v)=>upd(activeTpl.id,t=>({...t,docTitle:{...t.docTitle,[f]:v}}));
    const togCol = id  =>upd(activeTpl.id,t=>({...t,columns:t.columns.map(c=>c.id===id?{...c,enabled:!c.enabled}:c)}));

    const onDragStart = i => setDragIdx(i);
    const onDragOver  = (e,i) => {
      e.preventDefault();
      if (dragIdx===null||dragIdx===i) return;
      upd(activeTpl.id,t=>{
        const cols=[...t.columns];
        const [mv]=cols.splice(dragIdx,1);
        cols.splice(i,0,mv);
        return {...t,columns:cols};
      });
      setDragIdx(i);
    };
    const onDragEnd = ()=>setDragIdx(null);

    const addTpl = () => {
      const name = prompt(L?'Tên mẫu mới:':'New template name:',L?'Mẫu mới':'New Template');
      if (!name) return;
      const tpl = makeTpl(activeDocType, activeTpl?.paperSize||'K80', name);
      setTemplates(ts=>[...ts,tpl]);
      setActiveTplId(tpl.id);
    };
    const dupTpl = tpl => {
      const copy={...JSON.parse(JSON.stringify(tpl)),id:`t${Date.now()}`,name:tpl.name+(L?' (bản sao)':' (copy)'),isDefault:false};
      setTemplates(ts=>[...ts,copy]);
      setActiveTplId(copy.id);
    };
    const delTpl = id => {
      setTemplates(ts=>ts.filter(t=>t.id!==id));
      const remaining = docTpls.filter(t=>t.id!==id);
      setActiveTplId(remaining[0]?.id||null);
    };
    const setDefault = id => {
      setTemplates(ts=>ts.map(t=>t.docType===activeDocType?{...t,isDefault:t.id===id}:t));
    };
    const switchDoc = dt => {
      setActiveDocType(dt);
      const dts = templates.filter(t=>t.docType===dt);
      setActiveTplId((dts.find(t=>t.isDefault)||dts[0])?.id||null);
      setEdTab('header');
    };

    /* ── sub-editors ── */
    const EdHeader = () => (
      <div style={{display:'flex',flexDirection:'column',gap:7}}>
        {[['logo',L?'Hiển thị logo':'Show logo'],['storeName',L?'Tên cửa hàng':'Store name'],
          ['address',L?'Địa chỉ':'Address'],['phone',L?'Số điện thoại':'Phone'],
          ['taxId',L?'Mã số thuế (MST)':'Tax ID (MST)'],['website','Website']].map(([f,label])=>(
          <div key={f} className="tog-row" style={{margin:0}}>
            <span style={{fontSize:12,fontWeight:600}}>{label}</span>
            <Tog on={activeTpl.header[f]} onChange={v=>updH(f,v)}/>
          </div>
        ))}
      </div>
    );

    const EdColumns = () => (
      <div style={{display:'flex',flexDirection:'column',gap:5}}>
        <div style={{fontSize:10,color:'var(--t2)',marginBottom:2,fontStyle:'italic'}}>
          {L?'⠿ Kéo để sắp xếp · bật/tắt để ẩn/hiện cột':'⠿ Drag to reorder · toggle to show/hide columns'}
        </div>
        {activeTpl.columns.map((col,i)=>(
          <div key={col.id} draggable
            onDragStart={()=>onDragStart(i)} onDragOver={e=>onDragOver(e,i)} onDragEnd={onDragEnd}
            style={{display:'flex',alignItems:'center',gap:8,padding:'7px 10px',
              background:dragIdx===i?'var(--acs)':'var(--cv)',
              border:`1px solid ${dragIdx===i?'var(--acb)':'var(--bd)'}`,
              borderRadius:8,cursor:'grab',transition:'background .1s, border-color .1s',
              opacity:col.enabled?1:.45,
            }}>
            <span style={{opacity:.3,fontSize:14,flexShrink:0,userSelect:'none'}}>⠿</span>
            <div style={{flex:1}}>
              <div style={{fontSize:12,fontWeight:600,color:col.enabled?'var(--t1)':'var(--t3)'}}>{L?col.vi:col.en}</div>
              <div style={{fontSize:9,color:'var(--t3)',fontStyle:'italic'}}>{L?col.en:col.vi} · <span style={{fontFamily:'var(--mono)',fontSize:9}}>{`{{items.${col.id}}}`}</span></div>
            </div>
            <Tog on={col.enabled} onChange={()=>togCol(col.id)}/>
          </div>
        ))}
      </div>
    );

    const EdFooter = () => (
      <div style={{display:'flex',flexDirection:'column',gap:7}}>
        <div className="tog-row" style={{margin:0}}>
          <span style={{fontSize:12,fontWeight:600}}>{L?'Lời cảm ơn':'Thank-you message'}</span>
          <Tog on={activeTpl.footer.thankYou} onChange={v=>updFt('thankYou',v)}/>
        </div>
        {activeTpl.footer.thankYou&&(
          <input className="fi" style={{fontSize:11}} value={activeTpl.footer.thankYouText}
            onChange={e=>updFt('thankYouText',e.target.value)}/>
        )}
        <div style={{height:1,background:'var(--bd)',margin:'4px 0'}}/>
        <div style={{fontSize:9,fontWeight:700,color:'var(--t3)',textTransform:'uppercase',letterSpacing:'.05em'}}>{L?'Chữ ký':'Signatures'}</div>
        {[['sigBuyer',L?'Người mua hàng':'Buyer'],['sigSeller',L?'Người bán hàng':'Seller'],['sigWarehouse',L?'Thủ kho':'Warehouse keeper']].map(([f,label])=>(
          <div key={f} className="tog-row" style={{margin:0}}>
            <span style={{fontSize:12,fontWeight:600}}>{label}</span>
            <Tog on={activeTpl.footer[f]} onChange={v=>updFt(f,v)}/>
          </div>
        ))}
        <div style={{height:1,background:'var(--bd)',margin:'4px 0'}}/>
        <div style={{fontSize:9,fontWeight:700,color:'var(--t3)',textTransform:'uppercase',letterSpacing:'.05em'}}>{L?'QR & Thanh toán':'QR & Payment'}</div>
        {[
          ['eInvoiceQR',L?'QR tra cứu hóa đơn điện tử (Decree 70)':'E-invoice lookup QR (Decree 70)'],
          ['vietQR',L?'QR VietQR thanh toán':'VietQR payment code'],
          ['taxBlock',L?'Khối thông tin thuế GTGT':'VAT tax block'],
          ['paymentBank',L?'Thông tin ngân hàng':'Bank account details'],
        ].map(([f,label])=>(
          <div key={f} className="tog-row" style={{margin:0}}>
            <div style={{flex:1,marginRight:8}}><div style={{fontSize:12,fontWeight:600}}>{label}</div></div>
            <Tog on={activeTpl.footer[f]} onChange={v=>updFt(f,v)}/>
          </div>
        ))}
      </div>
    );

    const EdSettings = () => (
      <div style={{display:'flex',flexDirection:'column',gap:12}}>
        <div className="field">
          <div className="fl">{L?'Ngôn ngữ in':'Print language'}</div>
          <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
            {[['both','EN + VI (song ngữ)'],['vi','Tiếng Việt'],['en','English only']].map(([val,lab])=>(
              <button key={val} onClick={()=>upd(activeTpl.id,{lang:val})}
                style={{padding:'6px 10px',borderRadius:8,border:`1.5px solid ${activeTpl.lang===val?'var(--ac)':'var(--bd)'}`,background:activeTpl.lang===val?'var(--acs)':'var(--cv)',color:activeTpl.lang===val?'var(--act)':'var(--t2)',fontSize:11,fontWeight:700,cursor:'pointer',fontFamily:'var(--font)',transition:'all .12s'}}>
                {lab}
              </button>
            ))}
          </div>
        </div>
        <div className="field">
          <div className="fl">{L?'Khổ giấy':'Paper size'}</div>
          <div style={{display:'flex',gap:6}}>
            {PAPER_SIZES.map(sz=>(
              <button key={sz.id} onClick={()=>upd(activeTpl.id,{paperSize:sz.id})}
                style={{padding:'5px 10px',borderRadius:8,border:`1.5px solid ${activeTpl.paperSize===sz.id?'var(--ac)':'var(--bd)'}`,background:activeTpl.paperSize===sz.id?'var(--acs)':'var(--cv)',color:activeTpl.paperSize===sz.id?'var(--act)':'var(--t2)',fontSize:11,fontWeight:700,cursor:'pointer',fontFamily:'var(--font)',transition:'all .12s'}}>
                <div>{sz.label}</div><div style={{fontSize:8,fontWeight:400,opacity:.6}}>{sz.sub}</div>
              </button>
            ))}
          </div>
        </div>
        <div className="tog-row" style={{margin:0}}>
          <div><div style={{fontSize:12,fontWeight:700}}>{L?'Hiển thị số tài liệu':'Show document number'}</div></div>
          <Tog on={activeTpl.docTitle.docNo} onChange={v=>updDT('docNo',v)}/>
        </div>
        <div className="field">
          <div className="fl">{L?'Tiêu đề tùy chỉnh':'Custom title override'} <em>{L?'để trống = mặc định':'blank = default'}</em></div>
          <input className="fi" style={{fontSize:12}} placeholder={L?'Ví dụ: PHIẾU BÁN HÀNG':'e.g. SALES RECEIPT'} value={activeTpl.docTitle.titleOverride} onChange={e=>updDT('titleOverride',e.target.value)}/>
        </div>
        <div style={{height:1,background:'var(--bd)'}}/>
        <div>
          <button onClick={()=>setShowTokens(s=>!s)}
            style={{fontSize:11,fontWeight:700,color:'var(--act)',background:'none',border:'none',cursor:'pointer',fontFamily:'var(--font)',padding:0,display:'flex',alignItems:'center',gap:5}}>
            <span style={{fontSize:9}}>{showTokens?'▼':'▶'}</span>
            {L?'Placeholder tokens {{…}}':'Placeholder tokens {{…}}'}
          </button>
          {showTokens&&(
            <div style={{marginTop:8,display:'flex',flexWrap:'wrap',gap:4}}>
              {TOKENS.map(tk=>(
                <span key={tk} title={L?'Click để sao chép':'Click to copy'}
                  onClick={()=>navigator.clipboard?.writeText(tk)}
                  style={{padding:'2px 7px',background:'var(--ins)',color:'var(--in)',border:'1px solid var(--inb)',borderRadius:9999,fontSize:9.5,fontFamily:'var(--mono)',cursor:'pointer',transition:'opacity .1s'}}>
                  {tk}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    );

    /* empty state */
    if (!activeTpl) return (
      <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:40,gap:10,color:'var(--t3)',background:'var(--sf)',borderRadius:'var(--rmd)',boxShadow:'var(--e2)'}}>
        <div style={{fontSize:36}}>📄</div>
        <div style={{fontSize:13,fontWeight:700,color:'var(--t1)'}}>{L?'Chưa có mẫu in':'No templates yet'}</div>
        <div style={{fontSize:11,marginBottom:6}}>{L?'Tạo mẫu đầu tiên cho loại phiếu này':'Create the first template for this document type'}</div>
        <button className="btn btn-f btn-sm" onClick={addTpl}>+ {L?'Tạo mẫu':'New Template'}</button>
      </div>
    );

    return (
      <div style={{display:'flex',minHeight:560,background:'var(--cv)',borderRadius:'var(--rmd)',boxShadow:'var(--e2)',overflow:'hidden',border:'1px solid var(--bd)'}}>

        {/* ── LEFT: doc type list + template list ── */}
        <div style={{width:218,borderRight:'1px solid var(--bd)',display:'flex',flexDirection:'column',flexShrink:0,background:'var(--sf)'}}>
          {/* doc types */}
          <div style={{overflowY:'auto',borderBottom:'1px solid var(--bd)',flex:'0 0 auto',maxHeight:320}}>
            <div style={{padding:'8px 14px 3px',fontSize:9,fontWeight:700,color:'var(--t3)',textTransform:'uppercase',letterSpacing:'.05em'}}>{L?'Loại phiếu':'Document Types'}</div>
            {DOC_TYPES.map(dt=>(
              <button key={dt.id} onClick={()=>switchDoc(dt.id)}
                style={{display:'flex',alignItems:'center',gap:7,width:'100%',padding:'6px 12px',border:'none',borderLeft:`2px solid ${activeDocType===dt.id?'var(--ac)':'transparent'}`,background:activeDocType===dt.id?'var(--acs)':'transparent',color:activeDocType===dt.id?'var(--act)':'var(--t2)',fontWeight:activeDocType===dt.id?700:500,fontSize:11,cursor:'pointer',fontFamily:'var(--font)',textAlign:'left',transition:'all .1s'}}>
                <span style={{fontSize:13}}>{dt.ico}</span>
                <span style={{flex:1,lineHeight:1.3}}>{L?dt.vi:dt.en}</span>
                {templates.filter(t=>t.docType===dt.id).length>0&&(
                  <span style={{fontSize:8.5,background:'var(--bd)',borderRadius:9999,padding:'1px 5px',color:'var(--t2)',flexShrink:0}}>{templates.filter(t=>t.docType===dt.id).length}</span>
                )}
              </button>
            ))}
          </div>

          {/* template list */}
          <div style={{flex:1,overflow:'auto',padding:'6px 0'}}>
            <div style={{padding:'4px 12px 5px',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
              <span style={{fontSize:9,fontWeight:700,color:'var(--t3)',textTransform:'uppercase',letterSpacing:'.05em'}}>{L?'Mẫu in':'Templates'}</span>
              <button onClick={addTpl} style={{fontSize:10,fontWeight:700,color:'var(--act)',background:'none',border:'none',cursor:'pointer',fontFamily:'var(--font)',padding:'2px 4px'}}>+ {L?'Thêm':'Add'}</button>
            </div>
            {docTpls.length===0&&(
              <div style={{padding:'10px 14px',fontSize:10,color:'var(--t3)',fontStyle:'italic'}}>{L?'Chưa có mẫu':'No templates'}</div>
            )}
            {docTpls.map(tpl=>(
              <div key={tpl.id} onClick={()=>setActiveTplId(tpl.id)}
                style={{padding:'7px 12px',cursor:'pointer',background:activeTplId===tpl.id?'var(--acs)':'transparent',borderLeft:`2px solid ${activeTplId===tpl.id?'var(--ac)':'transparent'}`,transition:'all .1s'}}>
                <div style={{display:'flex',alignItems:'center',gap:5}}>
                  <span style={{fontSize:11,fontWeight:activeTplId===tpl.id?700:500,color:activeTplId===tpl.id?'var(--act)':'var(--t1)',flex:1,lineHeight:1.3}}>{tpl.name}</span>
                  {tpl.isDefault&&<span style={{fontSize:7.5,background:'var(--oks)',color:'var(--ok)',border:'1px solid var(--okb)',borderRadius:9999,padding:'0 4px',flexShrink:0}}>{L?'Mặc định':'Default'}</span>}
                </div>
                <div style={{fontSize:9,color:'var(--t3)',marginTop:1}}>{tpl.paperSize} · {tpl.lang==='both'?'EN+VI':tpl.lang.toUpperCase()}</div>
                {activeTplId===tpl.id&&(
                  <div style={{display:'flex',gap:4,marginTop:6,flexWrap:'wrap'}}>
                    {!tpl.isDefault&&<button onClick={e=>{e.stopPropagation();setDefault(tpl.id);}} style={{fontSize:9,padding:'2px 6px',borderRadius:5,border:'1px solid var(--bd)',background:'var(--cv)',color:'var(--t2)',cursor:'pointer',fontFamily:'var(--font)'}}>{L?'Đặt mặc định':'Set default'}</button>}
                    <button onClick={e=>{e.stopPropagation();dupTpl(tpl);}} style={{fontSize:9,padding:'2px 6px',borderRadius:5,border:'1px solid var(--bd)',background:'var(--cv)',color:'var(--t2)',cursor:'pointer',fontFamily:'var(--font)'}}>{L?'Sao chép':'Duplicate'}</button>
                    {docTpls.length>1&&<button onClick={e=>{e.stopPropagation();delTpl(tpl.id);}} style={{fontSize:9,padding:'2px 6px',borderRadius:5,border:'1px solid var(--erb)',background:'var(--ers)',color:'var(--er)',cursor:'pointer',fontFamily:'var(--font)'}}>{L?'Xóa':'Delete'}</button>}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* ── MIDDLE: editor ── */}
        <div style={{flex:1,display:'flex',flexDirection:'column',minWidth:0,background:'var(--cv)'}}>
          {/* toolbar */}
          <div style={{padding:'9px 14px',borderBottom:'1px solid var(--bd)',display:'flex',alignItems:'center',gap:8,background:'var(--sf)',flexWrap:'wrap'}}>
            <div style={{fontWeight:800,fontSize:13,color:'var(--t1)'}}>{activeTpl.name}</div>
            <span style={{fontSize:10,color:'var(--t2)',background:'var(--sf2)',border:'1px solid var(--bd)',borderRadius:6,padding:'1px 7px'}}>{activeTpl.paperSize}</span>
            <div style={{marginLeft:'auto',display:'flex',gap:6}}>
              <button className="btn btn-s btn-sm">{L?'In thử':'Test Print'}</button>
              <button className="btn btn-s btn-sm">PDF</button>
              <button className="btn btn-f btn-sm">
                <svg width={11} height={11} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                {L?'Lưu':'Save'}
              </button>
            </div>
          </div>
          {/* tabs */}
          <div style={{display:'flex',borderBottom:'1px solid var(--bd)',background:'var(--sf)',padding:'0 14px'}}>
            {[['header',L?'Đầu phiếu':'Header'],['columns',L?'Cột nội dung':'Columns'],['footer',L?'Chân phiếu':'Footer'],['settings',L?'Cài đặt khác':'Settings']].map(([tab,label])=>(
              <button key={tab} onClick={()=>setEdTab(tab)}
                style={{padding:'7px 13px',border:'none',borderBottom:`2px solid ${edTab===tab?'var(--ac)':'transparent'}`,background:'transparent',fontWeight:edTab===tab?700:500,fontSize:11,color:edTab===tab?'var(--act)':'var(--t2)',cursor:'pointer',fontFamily:'var(--font)',transition:'all .12s',whiteSpace:'nowrap'}}>
                {label}
              </button>
            ))}
          </div>
          {/* editor body */}
          <div style={{flex:1,overflow:'auto',padding:16}}>
            {edTab==='header'   && <EdHeader/>}
            {edTab==='columns'  && <EdColumns/>}
            {edTab==='footer'   && <EdFooter/>}
            {edTab==='settings' && <EdSettings/>}
          </div>
        </div>

        {/* ── RIGHT: live preview ── */}
        <div style={{width:304,borderLeft:'1px solid var(--bd)',display:'flex',flexDirection:'column',flexShrink:0,background:'var(--sf2)'}}>
          {/* preview header */}
          <div style={{padding:'9px 12px',borderBottom:'1px solid var(--bd)',background:'var(--sf)',display:'flex',alignItems:'center',gap:8}}>
            <div style={{fontSize:11,fontWeight:700,color:'var(--t1)'}}>{L?'Xem trước':'Live Preview'}</div>
            <div style={{fontSize:9,color:'var(--t3)',fontStyle:'italic',flex:1}}>{L?'Cập nhật thời gian thực':'Updates in real-time'}</div>
          </div>
          {/* paper size switcher */}
          <div style={{padding:'7px 10px',borderBottom:'1px solid var(--bd)',background:'var(--sf)',display:'flex',gap:4,flexWrap:'wrap'}}>
            {PAPER_SIZES.map(sz=>(
              <button key={sz.id} onClick={()=>upd(activeTpl.id,{paperSize:sz.id})}
                style={{padding:'3px 8px',borderRadius:9999,border:`1.5px solid ${activeTpl.paperSize===sz.id?'var(--ac)':'var(--bd)'}`,background:activeTpl.paperSize===sz.id?'var(--acs)':'var(--cv)',color:activeTpl.paperSize===sz.id?'var(--act)':'var(--t2)',fontSize:10,fontWeight:700,cursor:'pointer',fontFamily:'var(--font)',transition:'all .12s'}}>
                {sz.label} <span style={{fontWeight:400,opacity:.55,fontSize:9}}>{sz.sub}</span>
              </button>
            ))}
          </div>
          {/* preview scroll area */}
          <div style={{flex:1,overflow:'auto',padding:12,display:'flex',justifyContent:'center'}}>
            <LivePreview tpl={activeTpl} L={L}/>
          </div>
          {/* RBAC note */}
          <div style={{padding:'7px 12px',borderTop:'1px solid var(--bd)',fontSize:9,color:'var(--t3)',fontStyle:'italic',lineHeight:1.5}}>
            🔒 {L?'Chỉ Manager/Owner được sửa mẫu (RBAC Part 20). Mọi thay đổi được ghi nhật ký kiểm soát.':'Manager/Owner only may edit templates (RBAC Part 20). All changes are audit-logged.'}
          </div>
        </div>

      </div>
    );
  }

  Object.assign(window, { PrintTemplatesSection });
})();
